describe('Settings Page', function() {
  //var SettingsPage = function () {
  //  this.get = function () {
  //    browser.get(protractor.getInstance().baseUrl + 'settings')
  //  }
  //}
})
