describe('Help Page', function() {
  //var HelpPage = function () {
  //  this.get = function () {
  //    browser.get(protractor.getInstance().baseUrl + 'help')
  //  }
  //}
})
