module.exports = angular.module('stf.app-state', [
])
  .provider('AppState', require('./app-state-provider.js'))
