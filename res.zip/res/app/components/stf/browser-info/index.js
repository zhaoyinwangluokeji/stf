module.exports = angular.module('stf.browser-info', [

])
  .factory('BrowserInfo', require('./browser-info-service'))
