describe('BrowserInfo', function() {

  beforeEach(angular.mock.module(require('./').name))

  it('should ...', inject(function() {

	// expect(BrowserInfo.doSomething()).toEqual('something')

  }))

})
