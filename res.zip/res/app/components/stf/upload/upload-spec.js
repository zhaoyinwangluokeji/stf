describe('upload', function() {

  beforeEach(angular.mock.module(require('./').name))

	it('should ...', inject(function() {

    //var filter = $filter('uploadError')

		//expect(filter('input')).toEqual('output')

	}))

})
