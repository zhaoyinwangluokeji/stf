module.exports = angular.module('stf.image-onload', [

])
  .directive('imageOnload', require('./image-onload-directive'))
  .directive('imageOnloadAnimate', require('./image-onload-animate-directive'))
