require('./screen-keyboard.css')

module.exports = angular.module('stf.screen-keyboard', [

])
  .directive('screenKeyboard', require('./screen-keyboard-directive'))
