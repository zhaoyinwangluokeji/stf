module.exports = function screenTouchDirective() {
  return {
    restrict: 'A',
    link: function() {

    }
  }
}
