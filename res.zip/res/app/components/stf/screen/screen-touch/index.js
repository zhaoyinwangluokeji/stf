module.exports = angular.module('stf.screen-touch', [

])
  .directive('screenTouch', require('./screen-touch-directive'))
