module.exports = angular.module('stf/scaling', [])
  .factory('ScalingService', require('./scaling-service'))
