//input.form-control(type='text', placeholder='', ng-model='selectedAction',
// typeahead='action for action in activityActions')

module.exports = function textHistoryDirective() {
  return {
    restrict: 'A',
    template: '',
    link: function() {

    }
  }
}
