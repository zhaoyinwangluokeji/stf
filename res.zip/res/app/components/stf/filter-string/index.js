module.exports = angular.module('stf.filter-string', [

])
  .factory('FilterStringService', require('./filter-string-service'))
