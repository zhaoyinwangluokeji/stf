module.exports = angular.module('stf.timeline', [

])
  .factory('TimelineService', require('./timeline-service'))
