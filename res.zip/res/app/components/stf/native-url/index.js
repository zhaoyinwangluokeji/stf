module.exports = angular.module('stf.native-url', [

])
  .factory('NativeUrlService', require('./native-url-service'))
