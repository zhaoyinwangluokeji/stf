module.exports = angular.module('stf.icon-inside-input', [

])
  .directive('iconInsideInput', require('./icon-inside-input-directive'))
