module.exports = angular.module('stf.help-icon', [])
  .directive('helpIcon', require('./help-icon-directive'))
