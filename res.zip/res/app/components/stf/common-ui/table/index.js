require('./table.css')
require('script!ng-table/dist/ng-table')

module.exports = angular.module('stf/common-ui/table', [
  'ngTable'
])
