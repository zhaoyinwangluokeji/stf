require('./badge-icon.css')

module.exports = angular.module('stf.badge-icon', [

])
  .directive('badgeIcon', require('./badge-icon-directive'))
