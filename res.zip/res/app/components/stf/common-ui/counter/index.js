module.exports = angular.module('stf.counter', [

])
  .directive('countFrom', require('./counter-directive'))
