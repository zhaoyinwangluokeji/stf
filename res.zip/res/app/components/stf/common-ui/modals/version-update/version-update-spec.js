describe('VersionUpdateService', function() {

  beforeEach(angular.mock.module(require('ui-bootstrap').name))
  beforeEach(angular.mock.module(require('./').name))

  it('should ...', inject(function() {

	//expect(VersionUpdateService.doSomething()).toEqual('something');

  }))

})
