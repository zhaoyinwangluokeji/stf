module.exports = angular.module('stf.refresh-page', [])
  .directive('refreshPage', require('./refresh-page-directive'))
