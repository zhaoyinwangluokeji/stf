module.exports = angular.module('stf.filter-button', [])
  .directive('filterButton', require('./filter-button-directive'))
