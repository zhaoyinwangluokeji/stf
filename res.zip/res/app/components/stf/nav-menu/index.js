module.exports = angular.module('stf.nav-menu', [])
  .directive('navMenu', require('./nav-menu-directive'))
