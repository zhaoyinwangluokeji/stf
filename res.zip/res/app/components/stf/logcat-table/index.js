require('./logcat-table.css')

module.exports = angular.module('stf.logcat-table', [

])
  .directive('logcatTable', require('./logcat-table-directive'))
