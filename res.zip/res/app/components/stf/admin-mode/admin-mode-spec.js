describe('AdminModeService', function() {
  beforeEach(angular.mock.module(require('./').name))
})
