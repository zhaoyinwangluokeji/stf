module.exports = angular.module('stf.port-forwarding-service', [
])
  .factory('PortForwardingService', require('./port-forwarding-service'))
