module.exports = angular.module('stf.keys', [
  require('./add-adb-key').name
])
