//describe('KeycodesService', function() {
//
//  beforeEach(angular.mock.module(require('./').name));
//
//  it('should ...', inject(function(KeycodesService) {
//
//	//expect(KeycodesService.doSomething()).toEqual('something');
//
//  }));
//
//})
