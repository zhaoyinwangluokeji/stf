module.exports = function ControlPanesServiceFactory() {
  var ControlPanesService = {
  }


  return ControlPanesService
}
