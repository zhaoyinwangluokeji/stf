module.exports = function CpuCtrl() {

}
