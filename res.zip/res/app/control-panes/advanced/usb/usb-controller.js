module.exports = function UsbCtrl() {

}
