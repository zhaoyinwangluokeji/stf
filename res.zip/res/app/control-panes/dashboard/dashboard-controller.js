module.exports = function DashboardCtrl() {

}
