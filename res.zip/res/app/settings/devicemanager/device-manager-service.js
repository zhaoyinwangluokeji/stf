var oboe = require('oboe')

module.exports = function DeviceManagerService($http,
    AppState) {
    return {
        

    }

}