module.exports = function NotificationsCtrl() {

}
