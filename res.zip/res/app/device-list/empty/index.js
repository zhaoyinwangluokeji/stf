module.exports = angular.module('stf.device-list.empty', [
])
  .directive('deviceListEmpty', require('./device-list-empty-directive'))
