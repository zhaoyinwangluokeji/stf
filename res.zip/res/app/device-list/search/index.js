require('./device-list-search.css')

module.exports = angular.module('stf.device-list.search', [
])
