module.exports = function CompatIconsCtrl(
  $scope
, $rootScope
) {
  
}
