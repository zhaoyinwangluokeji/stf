require('./device-list-customize.css')

module.exports = angular.module('stf.device-list.customize', [
])
